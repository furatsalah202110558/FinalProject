﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;

namespace CarbonFootprintApp.Pages
{
    public class EditModel : PageModel
    {
        private readonly IConfiguration _config;
        public EditModel(IConfiguration config) => _config = config;

        public List<EnergyUsage> EnergyList { get; } = new();
        public List<TransportEntry> TransportList { get; } = new();
        public List<DietEntry> DietList { get; } = new();

        public void OnGet()
        {
            using var cn = new SqliteConnection(_config.GetConnectionString("Default"));
            cn.Open();
            var cmd = cn.CreateCommand();

            //  Energy Data 
            cmd.CommandText = @"SELECT Id, Electricity, Heating, Appliances,
                                Footprint, CreatedAt
                                FROM EnergyUsage ORDER BY CreatedAt DESC;";
            using (var rd = cmd.ExecuteReader())
                while (rd.Read())
                    EnergyList.Add(new EnergyUsage
                    (
                        rd.GetInt32(0),
                        rd.GetInt32(1),
                        rd.GetString(2),
                        rd.GetInt32(3),
                        rd.GetInt32(4),
                        rd.GetDateTime(5)
                    ));

            // Transport Data
            cmd.CommandText = @"SELECT Id, Vehicle, Distance, Frequency,
                                Footprint, CreatedAt
                                FROM Transport ORDER BY CreatedAt DESC;";
            using (var rd = cmd.ExecuteReader())
                while (rd.Read())
                    TransportList.Add(new TransportEntry
                    (
                        rd.GetInt32(0),
                        rd.GetString(1),
                        rd.GetInt32(2),
                        rd.GetString(3),
                        rd.GetInt32(4),
                        rd.GetDateTime(5)
                    ));

            //  Diet Data 
            cmd.CommandText = @"SELECT Id, Meals, Protein, Footprint, CreatedAt
                                FROM Diet ORDER BY CreatedAt DESC;";
            using (var rd = cmd.ExecuteReader())
                while (rd.Read())
                    DietList.Add(new DietEntry
                    (
                        rd.GetInt32(0),
                        rd.GetInt32(1),
                        rd.GetString(2),
                        rd.GetInt32(3),
                        rd.GetDateTime(4)
                    ));
        }

        public record EnergyUsage(
            int Id,
            int Electricity,
            string Heating,
            int Appliances,
            int Footprint,
            DateTime CreatedAt
        );

        public record TransportEntry(
            int Id,
            string Vehicle,
            int Distance,
            string Frequency,
            int Footprint,
            DateTime CreatedAt
        );

        public record DietEntry(
            int Id,
            int Meals,
            string Protein,
            int Footprint,
            DateTime CreatedAt
        );
    }
}
