﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Configuration;
using System;

namespace CarbonFootprintApp.Pages
{
    public class DataEntryModel : PageModel
    {
        private readonly IConfiguration _config;
        public DataEntryModel(IConfiguration config) => _config = config;

        //ENERGY 
        [BindProperty] public int? EnergyId { get; set; }
        [BindProperty] public int Electricity { get; set; }
        [BindProperty] public string Heating { get; set; }
        [BindProperty] public int Appliances { get; set; }

        //TRANSPORT
        [BindProperty] public int? TransportId { get; set; }
        [BindProperty] public string Vehicle { get; set; }
        [BindProperty] public int Distance { get; set; }
        [BindProperty] public string Frequency { get; set; }

        // DIET
        [BindProperty] public int? DietId { get; set; }
        [BindProperty] public int Meals { get; set; }
        [BindProperty] public string Protein { get; set; }

        public void OnGet(int? energyId, int? transportId, int? dietId)
        {
            using var cn = new SqliteConnection(_config.GetConnectionString("Default"));
            cn.Open();
            var cmd = cn.CreateCommand();

            //  Load Energy Data for Editing 
            if (energyId.HasValue)
            {
                cmd.CommandText = @"SELECT Electricity, Heating, Appliances FROM EnergyUsage WHERE Id = $id";
                cmd.Parameters.AddWithValue("$id", energyId.Value);
                using var rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    EnergyId = energyId;
                    Electricity = rd.GetInt32(0);
                    Heating = rd.GetString(1);
                    Appliances = rd.GetInt32(2);
                }
            }

            // Load Transport Data for Editing
            if (transportId.HasValue)
            {
                cmd.CommandText = @"SELECT Vehicle, Distance, Frequency FROM Transport WHERE Id = $id";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("$id", transportId.Value);
                using var rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    TransportId = transportId;
                    Vehicle = rd.GetString(0);
                    Distance = rd.GetInt32(1);
                    Frequency = rd.GetString(2);
                }
            }

            //  Load Diet Data for Editing 
            if (dietId.HasValue)
            {
                cmd.CommandText = @"SELECT Meals, Protein FROM Diet WHERE Id = $id";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("$id", dietId.Value);
                using var rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    DietId = dietId;
                    Meals = rd.GetInt32(0);
                    Protein = rd.GetString(1);
                }
            }
        }

        public IActionResult OnPostEditEnergy()
        {
            using var cn = new SqliteConnection(_config.GetConnectionString("Default"));
            cn.Open();
            var cmd = cn.CreateCommand();

            if (EnergyId.HasValue)
            {
                cmd.CommandText = @"UPDATE EnergyUsage 
                                    SET Electricity = $e, Heating = $h, Appliances = $a 
                                    WHERE Id = $id";
                cmd.Parameters.AddWithValue("$id", EnergyId);
            }
            else
            {
                cmd.CommandText = @"INSERT INTO EnergyUsage (Electricity, Heating, Appliances, Footprint, CreatedAt) 
                                    VALUES ($e, $h, $a, 0, CURRENT_TIMESTAMP)";
            }

            cmd.Parameters.AddWithValue("$e", Electricity);
            cmd.Parameters.AddWithValue("$h", Heating);
            cmd.Parameters.AddWithValue("$a", Appliances);
            cmd.ExecuteNonQuery();

            return RedirectToPage("/Edit");
        }

        public IActionResult OnPostEditTransport()
        {
            using var cn = new SqliteConnection(_config.GetConnectionString("Default"));
            cn.Open();
            var cmd = cn.CreateCommand();

            if (TransportId.HasValue)
            {
                cmd.CommandText = @"UPDATE Transport 
                                    SET Vehicle = $v, Distance = $d, Frequency = $f 
                                    WHERE Id = $id";
                cmd.Parameters.AddWithValue("$id", TransportId);
            }
            else
            {
                cmd.CommandText = @"INSERT INTO Transport (Vehicle, Distance, Frequency, Footprint, CreatedAt) 
                                    VALUES ($v, $d, $f, 0, CURRENT_TIMESTAMP)";
            }

            cmd.Parameters.AddWithValue("$v", Vehicle);
            cmd.Parameters.AddWithValue("$d", Distance);
            cmd.Parameters.AddWithValue("$f", Frequency);
            cmd.ExecuteNonQuery();

            return RedirectToPage("/Edit");
        }

        public IActionResult OnPostEditDiet()
        {
            using var cn = new SqliteConnection(_config.GetConnectionString("Default"));
            cn.Open();
            var cmd = cn.CreateCommand();

            if (DietId.HasValue)
            {
                cmd.CommandText = @"UPDATE Diet 
                                    SET Meals = $m, Protein = $p 
                                    WHERE Id = $id";
                cmd.Parameters.AddWithValue("$id", DietId);
            }
            else
            {
                cmd.CommandText = @"INSERT INTO Diet (Meals, Protein, Footprint, CreatedAt) 
                                    VALUES ($m, $p, 0, CURRENT_TIMESTAMP)";
            }

            cmd.Parameters.AddWithValue("$m", Meals);
            cmd.Parameters.AddWithValue("$p", Protein);
            cmd.ExecuteNonQuery();

            return RedirectToPage("/Edit");
        }
    }
}
