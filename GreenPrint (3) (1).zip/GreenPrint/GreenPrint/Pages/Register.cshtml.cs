﻿ using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Configuration;

public class RegisterModel : PageModel
{
    private readonly IConfiguration _config;

    public RegisterModel(IConfiguration config)
    {
        _config = config;
    }

    [BindProperty]
    public User User { get; set; }

    public IActionResult OnPost()
    {
        if (!ModelState.IsValid)
            return Page();

        string connectionString = _config.GetConnectionString("Default");
        using var connection = new SqliteConnection(connectionString);
        connection.Open();

        var command = connection.CreateCommand();
        command.CommandText =
            "INSERT INTO Users (FullName, Email, Password) VALUES ($fullName, $email, $password)";
        command.Parameters.AddWithValue("$fullName", User.FullName);
        command.Parameters.AddWithValue("$email", User.Email);
        command.Parameters.AddWithValue("$password", User.Password); 

        command.ExecuteNonQuery();


        return RedirectToPage("Index"); 
    }
}
